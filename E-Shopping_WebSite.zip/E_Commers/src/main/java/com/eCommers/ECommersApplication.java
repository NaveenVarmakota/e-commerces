package com.eCommers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECommersApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommersApplication.class, args);
	}

}
