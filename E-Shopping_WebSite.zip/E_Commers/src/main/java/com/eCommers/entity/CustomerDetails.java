package com.eCommers.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class CustomerDetails {
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int id;
		@Column(name = "First_Name",nullable = false,length = 55)
		private String firstname;
		@Column(name = "Last_Name",nullable = false,length = 55)
		private String lastname;
		@Column(name = "Email_Id",nullable = false,unique = true,length = 65)
		private String email;
		@Column(name = "Password",nullable = false,length = 55,unique = true)
		private String password;
		@Column(name = "Ph_Number",nullable = false,length = 10,unique = true)
		private long mobilenumber;
		@Column(name = "Address",nullable = false,length = 55)
		private String address;
		@Column(name = "Gender",nullable = false,length = 55)
		private String gender;
}
